ReadMe
CrackingArena.zip file contains:
ReadMe.txt
CrackingArena.sql


Posts: 44,927
Language: English
Date range: 4/8/2013 � 2/24/2018
Topics covered: Hacking based topics
This collection contains data about forums� posts including threadTitle, subforum, authorName, postAuthorJoinDate, postDate, ContentWithHTMLTag(raw post content), flatContent(post content without HTML tags).

Collection method:
This dataset was collected from CrackingAren forum using Offline Explorer to download the forum web pages, then a Java based parser to parse out data from the forums.
The data format is a self-contained mySQL dump file. MySQL is required to import the dump file.

How to cite this dataset:
Author(s): Robert Schweitzer, Ning Zhang, Mohammadreza Ebrahimi

Title: Hacker Web Forum Collection: CrackingArena Forum Dataset

Publisher: University of Arizona Artificial Intelligence Lab, AZSecure-data, Director Hsinchun Chen

Location: [AZSecure-data has not yet implemented Digital Object Identifiers or Persistent URLs, please 
copy and paste the location where you retrieve this file from within http://www.azsecure-data.org

Publication date: April, 29, 2018



citation:
Robert Schweitzer, Ning Zhang, Mohammadreza Ebrahimi. Hacker Web Forum Collection: Hackhound Forum Dataset. University of Arizona Artificial Intelligence Lab, AZSecure-data, Director Hsinchun Chen. Available http://www.azsecure-data.org/ [29 April 2018]




