ReadMe
Xakepok.zip file contains:
ReadMe.txt
Xakepok.sql


Posts: 48,034
Language: Russian
Date range: 4/15/2009 � 10/18/2017
Topics covered: Hacking based topics
This collection contains data about forums� posts including threadTitle, authorName, postAuthorJoinDate, postDate, postSequence, ContentWithHTMLTag(raw post content), flatContent(post content without HTML tags).

Collection method:
This dataset was collected from Xakepok forum using Offline Explorer to download the forum web pages, then a Java based parser to parse out data from the forums.
The data format is a self-contained mySQL dump file. MySQL is required to import the dump file.

How to cite this dataset:
Author(s): Guadalupe Angeles, Ning Zhang, Mohammadreza Ebrahimi

Title: Hacker Web Forum Collection: Xakepok Forum Dataset

Publisher: University of Arizona Artificial Intelligence Lab, AZSecure-data, Director Hsinchun Chen

Location: [AZSecure-data has not yet implemented Digital Object Identifiers or Persistent URLs, please 
copy and paste the location where you retrieve this file from within http://www.azsecure-data.org

Publication date: May, 1, 2018



citation:
Guadalupe Angeles, Ning Zhang, Mohammadreza Ebrahimi. Hacker Web Forum Collection: Hackhound Forum Dataset. University of Arizona Artificial Intelligence Lab, AZSecure-data, Director Hsinchun Chen. Available http://www.azsecure-data.org/ [1 May 2018]




